console.log(str);
console.log(abc);
//console.log(second);
var str:String;
var abc:any="abc123";
let second:string="abv"
console.log(second);
findMe(10,20);
console.log(hello());

function findMe(a,b){

    console.log("this is a function",a+b);
}

var hello = function ppt(){
console.log('hello World');
}