console.log(str);
console.log(abc);
var str;
var abc = "abc123";
var second = "abv";
console.log(second);
findMe(10, 20);
console.log(hello());
function findMe(a, b) {
    console.log("this is a function", a + b);
}
var hello = function ppt() {
    console.log('hello World');
};
