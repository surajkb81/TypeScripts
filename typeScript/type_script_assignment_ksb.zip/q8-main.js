"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var lib = require("./q8-modules.js");
console.log(lib.additions(3, 4));
console.log(lib.subtractions(6, 2));
console.log(lib.multiplications(3, 6));
console.log(lib.divisions(3, 6));
