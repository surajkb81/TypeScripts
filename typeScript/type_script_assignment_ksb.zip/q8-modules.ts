// class ArithmeticOps {
//     constructor(){
//     }
    
    export function additions(a: number, b: number): number{
        return a+b;
    }
    export function subtractions(a:number,b:number):number{
        return a-b;
    }
    export function multiplications(a:number,b:number):number{
        return a*b;
    }
    export function divisions(a:number,b:number):number{
        return a/b;
    }
// }


// let obj = new ArithmeticOps();
// console.log(obj.additions(3,6));
// console.log(obj.subtractions(6,2));
// console.log(obj.multiplications(3,6));
// console.log(obj.divisions(3,6));