var x = "abc999";
var y = "abc999";
var x = "Second Tme initialised";
var p = 2.10;
var a = "this is new";
var b = "this is old";
a = "second time initialised";
console.log(x, y, p, a, b);
