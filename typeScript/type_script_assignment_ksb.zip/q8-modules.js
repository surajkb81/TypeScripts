"use strict";
// class ArithmeticOps {
//     constructor(){
//     }
Object.defineProperty(exports, "__esModule", { value: true });
exports.additions = additions;
exports.subtractions = subtractions;
exports.multiplications = multiplications;
exports.divisions = divisions;
function additions(a, b) {
    return a + b;
}
function subtractions(a, b) {
    return a - b;
}
function multiplications(a, b) {
    return a * b;
}
function divisions(a, b) {
    return a / b;
}
// }
// let obj = new ArithmeticOps();
// console.log(obj.additions(3,6));
// console.log(obj.subtractions(6,2));
// console.log(obj.multiplications(3,6));
// console.log(obj.divisions(3,6));
