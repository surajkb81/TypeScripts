let display:string="Hello World";

console.log(display);