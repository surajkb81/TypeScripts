var x:string = "abc999";
var y:any = "abc999";
var x = "Second Tme initialised";
const p=2.10;

let a:string="this is new";
let b:string="this is old";
a="second time initialised";

console.log(x,y,p,a,b);