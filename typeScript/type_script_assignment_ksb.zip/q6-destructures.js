var arr = [1, 5, 3, 6, 8];
// Using array destructuring
var first = arr[0], second = arr[1], third = arr[2], fourth = arr[3], fifth = arr[4];
console.log("Original Array:", arr);
console.log("First Element:", first);
console.log("Second Element:", second);
console.log("Third Element:", third);
console.log("Fourth Element:", fourth);
console.log("Fifth Element:", fifth);
