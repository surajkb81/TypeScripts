let arr = [1,5,3,6,8];

// Using array destructuring
let [first, second, third, fourth,fifth] = arr;

console.log("Original Array:", arr);
console.log("First Element:", first);
console.log("Second Element:", second);
console.log("Third Element:", third);
console.log("Fourth Element:", fourth);
console.log("Fifth Element:", fifth);
