var display = "Hello World";
console.log(display);
